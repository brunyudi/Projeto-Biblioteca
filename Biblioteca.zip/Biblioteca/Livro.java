package Biblioteca;

public class Livro {
	private int idLivro;
	private String titulo;
	private String autor;
	private float preco;
	private Disponibilidade dispLivro;

	// construtor
	// métodos getters, setters, toString, compareTo etc conforme a
	// modelagem e encapsulamento especificados mais o que equipe decidir implementa

}
