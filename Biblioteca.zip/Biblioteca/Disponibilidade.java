package Biblioteca;

public enum Disponibilidade {
	DISPONIVEL, CONSULTALOCAL, EMPRESTADO, DANIFICADO, EXTRAVIADO;
}
