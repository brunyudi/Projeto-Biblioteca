package Principal;

import java.util.ArrayList;

import Amigo.*;
import Emprestimo.*;
import Biblioteca.*;

public class Principal {
	
	private static Biblioteca bib = new Biblioteca("Biblioteca Pessoal");
	private static ListaEmprestimos emprestimos = new ListaEmprestimos();
	private static ListaAmigos amigos = new ListaAmigos();
	
	public static void main(String[] args) {

		// as diversas funcoes static na main servir�o para implementar as op��es do menu
		// efetuar o controle da aplica��o e a intera��o com o usu�rio
		// v�rias formas para criar o(s) menu(s) e articular as classes
		// e para manipular os respectivos objetos (usando as listas, os IDs e/ou refer�ncias diretas)
		// todas as entradas e sa�das de dados ficam nesta classe Principal
		// classes de modelagem sem sout ou scanner, apenas cuidando dos seus respectivos atributos

		
		// aqui apenas alguns exemplos de manipula��o hardcoded em rela��o a amigos para ilustrar
		// a opera��o das listas bib e emprestimos � semelhante
		int idAmigo;
		idAmigo = amigos.addAmigo("Fulano", "(41) 99876-5432");
		System.out.println("Adicionado com codigo " + idAmigo);

		idAmigo = amigos.addAmigo("Ciclano", "(47) 98123-2121");
		System.out.println("Adicionado com codigo " + idAmigo);

		for (int i =0; i < amigos.getListaAmigosSize(); i++) {
			Amigo amigo = amigos.getAmigo(i);
			System.out.println("Nome: " + amigo.getNome());
			System.out.println("Celular: " + amigo.getCelular());
		}
		
		
		/*  Poss�vel menu principal do sistema Biblioteca Pessoal
	     *  0 - sair
	     *  1 - cadastrar livro
	     *  2 - cadastrar amigo
	     *  3 - emprestar
	     *  4 - devolver
	     *  5 - listar emprestimos atuais
	     *  6 - listar hist�rico de empr�stimos de um livro
	     *  7 - listar toda a biblioteca
	     */
			
	}
}
